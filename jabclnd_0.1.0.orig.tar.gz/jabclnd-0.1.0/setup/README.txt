DO NOT CHANGE OR REMOVE jabclnd_plugin.pyc FILE IN THIS DIRECTORY!!!

It is required for correct setup.py functioning when installing
or uninstalling Twisted plugin (twisted/plugins/jabclnd_plugin.py).